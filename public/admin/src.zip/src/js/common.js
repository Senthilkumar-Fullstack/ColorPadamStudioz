angular.isUndefinedOrNull = function(val) {
    return angular.isUndefined(val) || val === null 
};